<?php
$dbservername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "asd";
$conn = mysqli_connect($dbservername,$dbusername,$dbpassword,$dbname);