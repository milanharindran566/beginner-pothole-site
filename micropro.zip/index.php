<html>
<body>
<form action="report.php" method="POST">

<button type="submit" name="register">Register</button>
</form>
<form action="search.php" method="POST">

<button type="submit" name="search">Search</button>
</form>

<form action="officer.php" method="POST">

<button type="submit" name="authority">Authority</button>
</form>
</body>
</html>