<?php
$dbservername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "officer";
$connx = mysqli_connect($dbservername,$dbusername,$dbpassword,$dbname);