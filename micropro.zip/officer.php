<html>
<body>
<form action="login.php" method="POST">

<button type="submit" name="login">Login</button>
</form>
<form action="signup.php" method="POST">

<button type="submit" name="signup">Signup</button>
</form>

</body>
</html>